package com.baidu.ocr.demo;

import android.content.Context;
import android.os.LocaleList;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 数据解析工具类
 *
 * 含两个公共方法：
 *      获取数据：getDatas()
 *      更新数据：updateData()
 *
 * Created by Y on 2018/4/27.
 */

public class ParseDataUtil {
    private Context context;
    private String[] keys;
    private List<Map<String, Object>> Datas = null;
    private Map<String, Object> map = new HashMap<>();

    public ParseDataUtil(Context context){
        this.context = context;
        keys = context.getResources().getStringArray(R.array.keys_array);
    }

    /**
     * 得到数据列表
     * @param JsonString json字符串
     * @return 数据列表（无数据时返回null）
     */
    public List<Map<String, Object>> getDatas(String JsonString){
        if (Datas == null)
            Datas = parseJsonString(JsonString);

        return Datas;
    }

    /**
     * 更新数据
     * @param oldKey 旧键
     * @param newKey 新键
     * @param newValue 新值
     */
    public void updateData(String oldKey, String newKey, String newValue){
        map.remove(oldKey);
        map.put(newKey, newValue);
    }

    private List<Map<String, Object>> parseJsonString(String JsonString){
        List<Map<String, Object>> result = new ArrayList<>();

        List<String> dataList = getDataList(JsonString);

        if (dataList != null){
            for (String data : dataList){
                String[] dataItem = data.split("(?<=(\\d|_|[A-Za_z]|%|\\s))(?=[\\u4E00-\\u9FA5]+)");
                for (int i = 0; i < dataItem.length; i++){
                    String temp = dataItem[i];
                    String[] item = temp.split("(?<=[\\u4E00-\\u9FA5])(?=(\\d|_|[A-Za_z]|%|\\s))");
                    if (containsKey(temp)){
                        map.put(item[0], item[1]);
                    }else {
                        if (temp.startsWith("GB")){
                            map.put("标准代号", temp);
                        }
                        if (temp.startsWith("相")){
                            map.put("相数", dataItem[i-1].substring(dataItem[i-1].length()-1));
                        }
                        if (temp.toUpperCase().endsWith("HZ")){
                            map.put("额定频率", item[item.length-1]);
                        }
                        if (temp.toLowerCase().endsWith("kg")){
                            map.put("重", item[item.length-1]);
                        }
                    }
                }
            }
        } else {
            return null;
        }

        result.add(map);
        Log.i("analy","ok");

        return result;
    }

    /**
     * 得到字符串列表
     * @param JsonString json字符串
     * @return 字符串列表
     */
    private List<String> getDataList(String JsonString){
        List<String> result = new ArrayList<>();

        try {
            JSONObject jsonObject = new JSONObject(JsonString);

            if (jsonObject.getInt("words_result_num") <= 0)
                return null;

            JSONArray jsonArray = jsonObject.getJSONArray("words_result");
            for (int i = 0; i < jsonArray.length(); i++){
                JSONObject data_item = jsonArray.getJSONObject(i);
                result.add(data_item.getString("words"));
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

        return result;
    }

    /**
     * 字符串是否包含预设键值
     * @param string 原字符串
     * @return 判断结果
     */
    private boolean containsKey(String string){
        boolean result = false;

        for (String key : keys)
            if (string.contains(key)) {
                result = true;
                break;
            }

        return result;
    }

}
