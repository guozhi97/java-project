package com.baidu.ocr.demo;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.ActionBar;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.MediaController;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.StringTokenizer;

public class AnalysisResult extends Activity implements MyDialog.DialogListner {

    public final static String databaseName="electirc";
    public final static String tableName="information";
    public final static String databasePath= Environment.getExternalStorageDirectory().getPath()+"/";


    private ImageView imageView;
    private ListView listView;
    private SimpleAdapter simpleAdapter;
    private List<Map<String, Object>> datalist;
    private  int position=-1;
    MyDialog dialog;
    List<Map<String, Object>> data;

    private String imagePath = "/sdcard/temp.jpg";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_analysis_result);
        Intent intent = getIntent();
        imagePath = intent.getStringExtra("imagePath");
        initImage();
        initListview();
    }

    private void initListview() {
        simpleAdapter = new SimpleAdapter(AnalysisResult.this, initDatalist(), R.layout.result_list, new String[]{"name", "value"}, new int[]{R.id.list_name, R.id.list_value});
        listView = (ListView) findViewById(R.id.result_listview);
        listView.setAdapter(simpleAdapter);
       listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
           @Override
           public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                position = i;
               dialog = new MyDialog(AnalysisResult.this,AnalysisResult.this);

               dialog.show();
//               Window window = dialog.getWindow();
//               window.setContentView(R.layout.dialog);
           }
       });
    }

    private List<Map<String, Object>> initDatalist() {
        datalist = new ArrayList<Map<String, Object>>();
        Intent intent = getIntent();
        String result = intent.getStringExtra("result");
        Log.i("content1",result+"");
        try {
            ParseDataUtil util = new ParseDataUtil(AnalysisResult.this);
            data = util.getDatas(result);
        }catch (Exception e){


        }finally {
            if (data==null){
                Toast.makeText(AnalysisResult.this,"解析失败，请摆正照片",Toast.LENGTH_SHORT).show();
                finish();
            }
        }

        Set<String> set = data.get(0).keySet();
        for (String name:set){
            Map<String,Object> map = new HashMap<String,Object>();
            map.put("name",name);
            String value = (String) data.get(0).get(name);
            map.put("value",value);
            Log.i("content3",name+"--"+value);
            datalist.add(map);
        }
        return datalist;
    }

    private void addData(String name, String value) {
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("name", name);
        map.put("value", value);
        datalist.add(map);
        simpleAdapter.notifyDataSetChanged();
    }

    private void initImage() {
        imageView =(ImageView) findViewById(R.id.result_imageview);
        FileInputStream fileInputStream = null;

        try {
            fileInputStream = new FileInputStream(imagePath);
            Bitmap bitmap = BitmapFactory.decodeStream(fileInputStream);
            imageView.setImageBitmap(bitmap);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            Toast.makeText(AnalysisResult.this, "解析图片不存在", Toast.LENGTH_SHORT).show();
        }
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                Intent intent = new Intent(AnalysisResult.this,ImageDialog.class);
                intent.putExtra("imagePath",imagePath);
                startActivity(intent);
            }
        });
    }

    public void retureBtn(View view) {
        Intent intent = new Intent(AnalysisResult.this, MainActivity.class);
        startActivity(intent);
        finish();
    }



    public void addData(View view) {
        addData("","");
    }

    public void saveBtn(View view) {
        Products products = new Products(databaseName,tableName,databasePath);
        List<Map<String,Object>> list = new ArrayList<Map<String,Object>>();
        Map<String,Object> m = new HashMap<String, Object>();
        for (Map map:datalist){
            m.put((String) map.get("name"),(String)map.get("value"));
        }
        list.add(m);
        products.insertData(list);
        Toast.makeText(this,"save sucessful",Toast.LENGTH_SHORT).show();
    }

    @Override
    public void selectCity(String value) {
        if (position!=-1){
            String [] strings = value.split("-");
            Map<String,Object> map = datalist.get(position);
            map.put("name",strings[0]);
            map.put("value",strings[1]);
            simpleAdapter.notifyDataSetChanged();
            position=-1;
        }
    }
}
