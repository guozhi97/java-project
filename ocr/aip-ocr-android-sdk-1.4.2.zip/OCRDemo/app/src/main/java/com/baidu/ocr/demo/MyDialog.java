package com.baidu.ocr.demo;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2018/4/24/024.
 */

public class MyDialog extends Dialog {
    private  DialogListner dialogListner;

    public MyDialog(@NonNull Context context, DialogListner dialogListner) {
        super(context);
        this.dialogListner = dialogListner;

    }
    public interface  DialogListner{
        abstract void selectCity(String value);
    }

    private Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog);


        button = (Button) findViewById(R.id.dialog_btn);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              String str1="",str2="";
               EditText editText1 =  (EditText)(findViewById(R.id.dialog_e1));
               EditText editText2 =  (EditText)(findViewById(R.id.dialog_e2));
                if (!editText1.getText().toString().equals("")){
                    str1=editText1.getText().toString();
                }
                if (!editText1.getText().toString().equals("")){
                    str2=editText2.getText().toString();
                }
                if (str1!=null&&str2!=null&&!"".equals(str1)&&!"".equals(str2)) {
                    dialogListner.selectCity(str1 + "-" + str2);

                }else {
                    Toast.makeText((Activity)dialogListner,"don't input null",Toast.LENGTH_SHORT).show();
                }
                MyDialog.this.dismiss();
            }
        });

    }
}
