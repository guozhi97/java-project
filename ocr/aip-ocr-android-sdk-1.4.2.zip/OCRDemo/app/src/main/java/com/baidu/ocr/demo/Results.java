package com.baidu.ocr.demo;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Results extends AppCompatActivity implements AdapterView.OnItemClickListener, AdapterView.OnItemLongClickListener {
    private ListView listView;
    private List<Map<String,Object>> list;
    private SimpleAdapter adapter;
    Products products;
    public final static String TONEXT="id";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_results);
        setTitle("解析记录");
        products = new Products(AnalysisResult.databaseName,AnalysisResult.tableName,AnalysisResult.databasePath);

        adapter = new SimpleAdapter(Results.this,getList(),R.layout.results_item,new String[]{"id","date"},new int []{R.id.results_id,R.id.results_vid});
        listView = (ListView) findViewById(R.id.results_listView);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(this);
        listView.setOnItemLongClickListener(this);
    }
    private List<Map<String,Object>> getList(){
        list = new ArrayList<Map<String, Object>>();
        List<Map<String,Object>> li = products.queryData(0);
        for (Map map:li){
            Map<String,Object> map1 = new HashMap<String, Object>();
            map1.put("id",(String)map.get("_id"));
            map1.put("date",(String)map.get("vid"));
            list.add(map1);
        }
        return list;
    }


    public void nextView(View view) {
        Intent intent = new Intent(Results.this,MainActivity.class);
        startActivity(intent);
        finish();
    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        Intent intent = new Intent(Results.this,Results_Dailt.class);
        Map map = list.get(i);
        intent.putExtra(TONEXT,(String) map.get("id"));
        Log.i("nextView",i+"-"+(String) map.get("id"));
        startActivity(intent);
    }

    @Override
    public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
        final int ii = i;
        AlertDialog.Builder dialog = new AlertDialog.Builder(Results.this);
        dialog.setTitle("删除记录");
        dialog.setMessage("确定删除？");
        dialog.setPositiveButton("确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Map map = list.get(ii);
                String id = (String) map.get("id");
                if (products.deleteData(Integer.parseInt(id))){
                    list.remove(ii);
                    adapter.notifyDataSetChanged();
                    Toast.makeText(Results.this,"删除成功",Toast.LENGTH_SHORT).show();
                }else {
                    Toast.makeText(Results.this,"删除失败",Toast.LENGTH_SHORT).show();
                }
            }
        });
        dialog.setNegativeButton("取消", new DialogInterface.OnClickListener(){

            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        dialog.show();
        return true;
    }
}
