package com.baidu.ocr.demo;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Results_Dailt extends AppCompatActivity {

    private ListView listView;
    private List<Map<String,Object>> list;
    private SimpleAdapter adapter;
    private  Products products;
    private String id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_results__dailt);
        setTitle("解析详细记录");
        Intent intent = getIntent();
        id = intent.getStringExtra(Results.TONEXT);
        Log.i("id",id+"-");
        if (null==id||id.equals("")){
            id="0";
        }
        products = new Products(AnalysisResult.databaseName,AnalysisResult.tableName,AnalysisResult.databasePath);
        adapter = new SimpleAdapter(Results_Dailt.this,getList(),R.layout.result_list,new String[]{"name","value"},new int []{R.id.list_name,R.id.list_value});
        listView = (ListView) findViewById(R.id.results_dailt_listView);
        listView.setAdapter(adapter);
    }
    private List<Map<String,Object>> getList(){
        list = new ArrayList<Map<String, Object>>();
        List<Map<String,Object>> li = products.queryData(Integer.parseInt(id));
        Log.i("results_size",li.size()+"-");
        Map m = li.get(0);
        Set<String> set = m.keySet();
        for (String string :set){
            Map<String,Object> map1 = new HashMap<String, Object>();
            map1.put("name",string);
            map1.put("value",(String)m.get(string));
            Log.i("value",(String)m.get(string)+"-");
            Log.i("name",string+"-");
            list.add(map1);
        }
        return list;
    }
    public void nextView(View view) {
        Intent intent = new Intent( Results_Dailt.this,Results.class);
        startActivity(intent);
        finish();
    }
}
