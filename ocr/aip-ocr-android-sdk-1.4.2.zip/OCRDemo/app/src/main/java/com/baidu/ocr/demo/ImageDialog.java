package com.baidu.ocr.demo;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

import java.io.FileInputStream;

public class ImageDialog extends Activity {
    private  String imagePath;
    private ImageView imageView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_dialog);
        Intent intent = getIntent();
        imagePath = intent.getStringExtra("imagePath");
        imageView = (ImageView) findViewById(R.id.image_img);
        getView(imageView);
    }

    public void nextView(View view) {
        finish();
    }
    private void getView(ImageView imgView) {
        //  imgView.setLayoutParams(new ActionBar.LayoutParams(ActionBar.LayoutParams.MATCH_PARENT, ActionBar.LayoutParams.MATCH_PARENT));
        imgView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        FileInputStream fileInputStream;
        Matrix matrix = new Matrix();
        matrix.setRotate(90);
        try {
            fileInputStream = new FileInputStream(imagePath);
            Bitmap bitmap = BitmapFactory.decodeStream(fileInputStream);
            Bitmap bitmap1 = Bitmap.createBitmap(bitmap,0,0,bitmap.getWidth(),bitmap.getHeight(),matrix,true);
            imgView.setImageBitmap(bitmap1);
            fileInputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
            Log.i("printpic","error");
        }
    }
}
