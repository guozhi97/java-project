/*
 * Copyright (C) 2017 Baidu, Inc. All Rights Reserved.
 */
package com.baidu.ocr.ui.camera;

public interface PermissionCallback {
    boolean onRequestPermission();
}
