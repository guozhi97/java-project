package com.baidu.ocr.demo;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;


public class Products {
    private String databaseName = null;
    private String tableName = null;
    private String databasePath = null;
    private SQLiteDatabase database;
    private List<String> columnName=new ArrayList<String>();

    private String vidValue;

    public Products(String databaseName, String tableName, String databasePath) {
        this.databaseName = databaseName;
        this.tableName = tableName;
        this.databasePath = databasePath;
        builtDatabase();
        builtTable();
    }

    private void builtTable() {
        Log.i("tableName", tableName);
    //  database.execSQL("DROP TABLE IF EXISTS " + tableName);
        database.execSQL("create table if not exists " + tableName + " (_id integer primary key autoincrement,vid varchar(255))");
        updateColums();
    }

    private void builtDatabase() {
        database = SQLiteDatabase.openOrCreateDatabase(databasePath + databaseName + ".db3", null);
    }

    public boolean insertData(List<Map<String, Object>> datalist) {
        Map<String, Object> map;
        if (datalist.size() <= 0)
            return false;
        map = datalist.get(0);
        Set<String> set = map.keySet();
        Date day=new Date();
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String vidValue = df.format(day);
        for (String name : set) { // 添加缺少的列
            if (!findColumn(name)) {
                addColumn(name);
            }
        }

        StringBuffer sql = new StringBuffer("insert into " + tableName + " values(null,'" + vidValue+"'");
        for (int i = 0; i < columnName.size() - 2; i++) {
            sql.append(",'isempty'");
        }
        sql.append(" );");
        Log.i("addNullData", sql.toString());
        try {
            database.execSQL(sql.toString());
        } catch (Exception e) {
            Log.i("addNullData", "errror");
            return false;
        }

        sql = new StringBuffer("update " + tableName + " set ");
        sql.append("vid='" + vidValue + "'");
        for (String name : set) {
            String value = (String) map.get(name);
            sql.append("," + name + "='" + value + "'");
        }
        sql.append(" where vid='" + vidValue + "'");
        Log.i("alterNullData", sql.toString());
        try {
            database.execSQL(sql.toString());
            return true;
        } catch (Exception e) {
            Log.i("alterNullData", "errror");
            return false;
        }
    }


    public List<Map<String, Object>> queryData(int id ) {
        StringBuffer sql = new StringBuffer("select *  from " + tableName);
        if (id>0){
            sql.append(" where _id="+id);
        }
        try {
            Cursor cursor = database.rawQuery(sql.toString(), null);
            cursor.moveToFirst();
            List<Map<String, Object>> datalist = new ArrayList<Map<String, Object>>();
            Log.i("query",cursor.getColumnCount()+"-"+cursor.getCount());
            for (int j = 0; j < cursor.getCount(); j++) {
                Map<String, Object> map = new HashMap<String, Object>();
                Log.i("query",columnName.get(0).trim()+cursor.getString(0).trim()+"-");
                for (int i = 0; i < cursor.getColumnCount(); i++) {
                    try {
                        Log.i("results",i+"-"+columnName.get(i).trim()+"-"+cursor.getString(i).trim());
                    }catch (Exception e){
                        Log.i("query","close");
                    }
                    map.put(columnName.get(i).trim(), cursor.getString(i).trim());
                }
                datalist.add(map);

                cursor.moveToNext();
            }
            cursor.close();
            return datalist;
        } catch (Exception e) {
            Log.i("queryData", "error");
            return null;
        }
    }

    private boolean findColumn(String name) {
        for (String string : columnName)
            if (name.trim().equals(string.trim()))
                return true;
        return false;
    }

    public void updateColums() {
        Cursor cursor = database.rawQuery("select * from " + tableName + " where 0 ", null);
        String[]  columnName = cursor.getColumnNames();
        for (String string:columnName){
            Log.i("print",string+"-");
            this.columnName.add(string);
        }

    }

    private boolean addColumn(String name) {
        String sql = "alter table "+tableName+" add column "+name+" char(255)";
        Log.i("addcolum", sql);
        try {
            database.execSQL(sql);
            Log.i("addColumn","sucessful-"+name);
            columnName.add(name);
            return true;
        } catch (Exception e) {
            Log.i("addColumn","error-"+name+e.getMessage());
            return false;
        }

    }
    public boolean deleteData(int id){
        String sql = "delete from "+tableName+" where _id="+id;

        try {
            database.execSQL(sql);
            return true;
        }catch (Exception e){
            return false;
        }
    }

}
